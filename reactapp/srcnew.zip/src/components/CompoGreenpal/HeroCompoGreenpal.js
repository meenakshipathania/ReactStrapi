import React from 'react';

function HeroIncity() {
    return (
        <>
            <div className="appie-page-title-area components">
                <div className="container-fluid"></div>
            </div>
        </>
    );
}

export default HeroIncity;
